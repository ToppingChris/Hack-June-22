module.exports = {
    verbose: true,
    clearMocks: true,
    // preset: 'js-jest',
    testEnvironment: 'node',
    testTimeout: 10000
}