# ShareCare Post API

In order to run the API you'll need to set the following environment variables.

## Environment variables

| Variable name | Value |
| --- | --- |
|DATABASE_HOST|database hostname|
|DATABASE_PORT|database port|
|DATABASE_NAME|name of the database
|DATABASE_USERNAME|username of the database user|
|DATABASE_PASSWORD|password of the database user|
|MEDIA_SERVICE_URL|URL of ShareCare Media API|
